/* BUTTONS FUNCTIONS */

document.querySelector(".cocaclassic").addEventListener("click", function(){
  document.querySelector(".bottle-cap").style.background = "red";
  document.querySelector(".bottle-label").style.background = "red";
  document.querySelector(".bottle-brand").style.fontSize = "38px";
  document.querySelector(".bottle-brand").innerHTML = "Coca Cola";
});

document.querySelector(".cocalight").addEventListener("click", function(){
  document.querySelector(".bottle-cap").style.background = "grey";
  document.querySelector(".bottle-label").style.background = "grey";
  document.querySelector(".bottle-brand").style.fontSize = "32px";
  document.querySelector(".bottle-brand").innerHTML = "Coca Light";
});

document.querySelector(".cocazero").addEventListener("click", function(){
  document.querySelector(".bottle-cap").style.background = "black";
  document.querySelector(".bottle-label").style.background = "black";
  document.querySelector(".bottle-brand").style.fontSize = "32px";
  document.querySelector(".bottle-brand").innerHTML = "Coca Zero";
});

document.querySelector(".cocalife").addEventListener("click", function(){
  document.querySelector(".bottle-cap").style.background = "green";
  document.querySelector(".bottle-label").style.background = "green";
  document.querySelector(".bottle-brand").style.fontSize = "32px";
  document.querySelector(".bottle-brand").innerHTML = "Coca Life";
});

document.querySelector(".website-enter").addEventListener("click", function(){
  document.querySelector(".website-entrance").style.display = "none";
  colaAnthem.play();
  colaAnthem.volume = 0.2;
});

     /*Button Sound off and on*/

colaAnthem = new Audio('sounds/cola-anthem.mp3');

document.querySelector(".cola-song-on").addEventListener("click",function(){
  document.querySelector(".cola-song-on").style.display="none"
  document.querySelector(".cola-song-off").style.display="block"
  colaAnthem.pause();
});

document.querySelector(".cola-song-off").addEventListener("click",function(){
  document.querySelector(".cola-song-off").style.display="none"
  document.querySelector(".cola-song-on").style.display="block"
  colaAnthem.play();
  colaAnthem.volume = 0.2;
});

colaAnthem.addEventListener('ended', function(){
  colaAnthem.currentTime = 0;
  colaAnthem.play();
}, false);


/* SOUNDS FUNCTIONS */

sodaFizz = new Audio('sounds/soda-gas.mp3');

document.querySelector(".play-zone").addEventListener("mouseenter", event => {
  sodaFizz.play();
  sodaFizz.volume = 0.2;
});

document.querySelector(".play-zone").addEventListener("mouseleave", event => {
  sodaFizz.pause();
  sodaFizz.currentTime = 0;
});

sodaFizz.addEventListener('ended', function(){
  sodaFizz.currentTime = 0;
  sodaFizz.play();
}, false);
