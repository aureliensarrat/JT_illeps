# Shake-Cola
A simple bottle of Coca Cola made and animated only with HTML/CSS.  (School exercise on CSS animations and transitions).
(Only buttons and music are made in Javascript)

-------------

In doing this project I tried to respect the graphic and sound charter of the Coca Cola brand.(Up to the favicon).
So activate the sound for a more immersive experience ! 

-------------

The bottle can be shaken by moving the mouse over it. When you shake it, the bubbles accelerate and a gas sound starts to come on.
The clouds are also slightly animated.
The animation website contains 4 buttons to change the type of soda and 1 button to cut the background music.

-------------

The bubbles are inspired by the video "CSS Bubble Animation" by Twisted Core on Youtube.



Sarrat Aurélien
https://aureliensarrat.github.io/Shake-Cola/